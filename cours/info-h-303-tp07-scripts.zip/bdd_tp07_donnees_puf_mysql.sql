DROP TABLE IF EXISTS `F`;
CREATE TABLE IF NOT EXISTS `F` (
  `NF` int(11) NOT NULL default '0',
  `NomF` varchar(20) NOT NULL default '',
  `Statut` varchar(20) NOT NULL default '',
  `Ville` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`NF`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `F`
-- 

INSERT INTO `F` (`NF`, `NomF`, `Statut`, `Ville`) VALUES 
(1, 'A', 'Indépendant', 'Paris'),
(2, 'B', 'Grossiste', 'Paris'),
(3, 'C', 'Indépendant', 'Londres'),
(4, 'D', 'Grossiste', 'Paris'),
(5, 'E', 'Indépendant', 'Londres'),
(6, 'F', 'Grossiste', 'Bruxelles'),
(7, 'G', 'Indépendant', 'Liège'),
(8, 'H', 'Grossiste', 'Namur'),
(9, 'I', 'Indépendant', 'Charleroi'),
(10, 'J', 'Grossiste', 'Namur');

-- --------------------------------------------------------

-- 
-- Table structure for table `P`
-- 

DROP TABLE IF EXISTS `P`;
CREATE TABLE IF NOT EXISTS `P` (
  `NP` int(11) NOT NULL default '0',
  `NomP` varchar(20) NOT NULL default '',
  `Couleur` varchar(20) NOT NULL default '',
  `Poids` int(11) NOT NULL default '0',
  PRIMARY KEY  (`NP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `P`
-- 

INSERT INTO `P` (`NP`, `NomP`, `Couleur`, `Poids`) VALUES 
(1, 'iPod', 'rouge', 100),
(2, 'iPod', 'gris', 100),
(3, 'iMac', 'blanc', 300),
(4, 'MacBook', 'blanc', 200),
(5, 'MacBook', 'noir', 200);

-- --------------------------------------------------------

-- 
-- Table structure for table `U`
-- 

DROP TABLE IF EXISTS `U`;
CREATE TABLE IF NOT EXISTS `U` (
  `NU` int(11) NOT NULL default '0',
  `NomU` varchar(20) NOT NULL default '',
  `Ville` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`NU`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `U`
-- 

INSERT INTO `U` (`NU`, `NomU`, `Ville`) VALUES 
(1, 'A', 'Paris'),
(2, 'B', 'Paris'),
(3, 'C', 'Paris'),
(4, 'D', 'Londres'),
(5, 'E', 'Londres');

-- --------------------------------------------------------

-- 
-- Table structure for table `PUF`
-- 

DROP TABLE IF EXISTS `PUF`;
CREATE TABLE IF NOT EXISTS `PUF` (
  `NP` int(11) NOT NULL default '0',
  `NU` int(11) NOT NULL default '0',
  `NF` int(11) NOT NULL default '0',
  `Quantité` int(11) NOT NULL default '0',
  PRIMARY KEY  (`NP`,`NU`,`NF`),
  foreign key (NP) references P(NP),
  foreign key (NU) references U(NU),
  foreign key (NF) references F(NF)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `PUF`
-- 

INSERT INTO `PUF` (`NP`, `NU`, `NF`, `Quantité`) VALUES 
(1, 1, 1, 10),
(1, 1, 2, 15),
(5, 4, 3, 15),
(5, 5, 3, 15),
(5, 1, 3, 15),
(5, 2, 3, 1),
(5, 3, 3, 1),
(2, 1, 4, 1);
